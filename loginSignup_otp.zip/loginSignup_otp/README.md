# OTP Login System
<h2>Login System Using Phone number as username and password Or Login Using OTP</h2>

<div>
<b>Used Technologies</b>
<ul>
  <li>#Php</li>
  <li>#HTML #JS #CSS</li>
  <li>#MYSQL</li>
</ul>
</div>
<hr>

<div>
<b>How it Works?</b>
  <ul>
      Simple Procedural PHP Method. User have to enter his phone number, otp is send to his phone number. if otp is correct then session will create and redirects to another page.
    </ul>
</div>
<hr>
<div >
  <b>Install and Run code</b>
    <ul>
  <li>Download/Clone Repositery</li>
  <li>Install Apache, MySQL Server.</li>
  <li>Place Project Folder Under public_html/www folder</li>
  <li>Go to MySql and Create Database then Upload Given SQL File. or Import it in PhpMyadmin</li>
  <li>Go to Folder 'include/db.php' and update your database credentials.</li>
  <li>Access Project Through Localhost / 127.0.0.1 in Browser</li>
    </ul>
 </div>


